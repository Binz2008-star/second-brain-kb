#!/usr/bin/env python3
"""
sb - Unified CLI - ONE command does all (like opencode)
Usage:
  sb chat                    # Q&A
  sb agent "task"            # Full multi-agent autonomous
  sb search "query"          # Search brain
  sb status                  # Health check
  sb evolve                  # Self-improve
  sb switch <project>        # Switch repo
  sb ui                      # Start web UI + API
"""
import sys
import os
from pathlib import Path
import subprocess
import argparse

ROOT = Path(__file__).parent
KB_ROOT = ROOT.parent / "second-brain-kb"
if not KB_ROOT.exists():
    KB_ROOT = ROOT

def run(cmd, **kwargs):
    print(f"$ {cmd}")
    return subprocess.run(cmd, shell=True, **kwargs)

def cmd_chat(args):
    from brain_agent_v4 import interactive_v4
    import asyncio
    asyncio.run(interactive_v4())

def cmd_agent(args):
    from brain_agent_v4 import run_multi_agent
    import asyncio
    task = " ".join(args.task) if args.task else args.prompt
    if not task:
        task = input("Task: ")
    asyncio.run(run_multi_agent(task))

def cmd_search(args):
    query = " ".join(args.query)
    # Use brain.py for fast search
    brain_py = KB_ROOT / "brain.py"
    if brain_py.exists():
        run(f'python "{brain_py}" "{query}"')
    else:
        from brain_agent_v4 import search_brain
        import asyncio
        async def do_search():
            results = await search_brain(query, top_k=args.top_k)
            for r in results:
                print(f"\n[{r['project_id']}/{r['file_path']}] sim={r.get('similarity', 0):.3f}")
                print(r['content'][:800])
        asyncio.run(do_search())

def cmd_status(args):
    print("🔍 Checking Second Brain v4 status...\n")
    
    # Docker
    print("📦 Docker:")
    run("docker ps | findstr second-brain || docker ps | grep second-brain")
    
    # Ollama
    print("\n🤖 Ollama models:")
    run("ollama list")
    
    # Neon
    print("\n📡 Neon DB:")
    try:
        import asyncpg, asyncio
        from dotenv import load_dotenv
        load_dotenv()
        async def check():
            conn = await asyncpg.connect(os.getenv("NEON_DSN"))
            cnt = await conn.fetchval("SELECT COUNT(*) FROM chunks")
            print(f"  chunks: {cnt}")
            try:
                cnt2 = await conn.fetchval("SELECT COUNT(*) FROM chunks_v4")
                print(f"  chunks_v4: {cnt2}")
            except:
                print(f"  chunks_v4: not yet migrated")
            mem = await conn.fetchval("SELECT COUNT(*) FROM memory")
            print(f"  memory: {mem}")
            await conn.close()
        asyncio.run(check())
    except Exception as e:
        print(f"  ❌ DB check failed: {e}")
    
    # Projects
    print("\n📁 Projects:")
    for k in ["PROJECT_CONTENT_ENGINE", "PROJECT_LVYY", "PROJECT_RICO"]:
        v = os.getenv(k) or "(not set)"
        exists = Path(v).exists() if v != "(not set)" else False
        print(f"  {k}={v} {'✅' if exists else '❌'}")

def cmd_evolve(args):
    """Self-evolution - agent improves its own code"""
    from evolve import evolve
    import asyncio
    asyncio.run(evolve())

def cmd_ui(args):
    """Start API + Web UI"""
    api_py = ROOT / "api.py"
    if api_py.exists():
        print("🚀 Starting API + UI at http://localhost:8000")
        run(f'python "{api_py}"')
    else:
        print("API not found, starting simple chat")
        cmd_chat(args)

def cmd_switch(args):
    print(f"Switching to {args.project}")
    os.environ["CURRENT_PROJECT"] = args.project
    # Write to .env for persistence
    env_path = ROOT / ".env"
    if env_path.exists():
        content = env_path.read_text()
        if "CURRENT_PROJECT" in content:
            import re
            content = re.sub(r"CURRENT_PROJECT=.*", f"CURRENT_PROJECT={args.project}", content)
        else:
            content += f"\nCURRENT_PROJECT={args.project}\n"
        env_path.write_text(content)
    print(f"✅ Now in {args.project}")

def main():
    parser = argparse.ArgumentParser(prog="sb", description="Second Brain v4 - One CLI does all")
    sub = parser.add_subparsers(dest="cmd")
    
    # chat
    p_chat = sub.add_parser("chat", help="Interactive chat like OpenCode")
    p_chat.set_defaults(func=cmd_chat)
    
    # agent
    p_agent = sub.add_parser("agent", help="Full multi-agent autonomous task")
    p_agent.add_argument("task", nargs="*", help="Task description")
    p_agent.add_argument("--prompt", type=str, help="Task prompt")
    p_agent.set_defaults(func=cmd_agent)
    
    # search
    p_search = sub.add_parser("search", help="Semantic search")
    p_search.add_argument("query", nargs="+", help="Search query")
    p_search.add_argument("--top-k", type=int, default=6)
    p_search.set_defaults(func=cmd_search)
    
    # status
    p_status = sub.add_parser("status", help="Health check")
    p_status.set_defaults(func=cmd_status)
    
    # evolve
    p_evolve = sub.add_parser("evolve", help="Self-evolve and improve")
    p_evolve.set_defaults(func=cmd_evolve)
    
    # ui
    p_ui = sub.add_parser("ui", help="Start Web UI + API")
    p_ui.set_defaults(func=cmd_ui)
    
    # switch
    p_switch = sub.add_parser("switch", help="Switch project")
    p_switch.add_argument("project", help="Project id")
    p_switch.set_defaults(func=cmd_switch)
    
    # Default to chat if no args
    if len(sys.argv) == 1:
        cmd_chat(None)
        return
    
    args = parser.parse_args()
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
