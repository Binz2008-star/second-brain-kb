"""
FastAPI for Second Brain v4 - API + Web UI backend
Endpoints:
  POST /search - hybrid search
  POST /chat - chat with context
  POST /agent - multi-agent task
  GET /status - health
  GET /projects - list projects
  WS /ws/agent - streaming agent
"""
import os
import asyncio
from pathlib import Path
from typing import List, Optional
from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import asyncpg
import aiohttp

load_dotenv()

app = FastAPI(title="Second Brain v4", version="4.0")

NEON_DSN = os.getenv("NEON_DSN")
OLLAMA_EMBED_URL = os.getenv("OLLAMA_EMBED_URL", "http://127.0.0.1:11434/api/embed")
OLLAMA_CHAT_URL = os.getenv("OLLAMA_CHAT_URL", "http://127.0.0.1:11434/api/chat")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
CHAT_MODEL = os.getenv("CHAT_MODEL", "qwen2.5-coder:14b-16k")

# Models
class SearchRequest(BaseModel):
    query: str
    top_k: int = 8
    hybrid: bool = True

class ChatRequest(BaseModel):
    query: str
    top_k: int = 6
    stream: bool = True

class AgentRequest(BaseModel):
    task: str
    project: Optional[str] = None

# Import search from v4
try:
    import sys
    sys.path.insert(0, str(Path(__file__).parent))
    from brain_agent_v4 import search_brain
except:
    search_brain = None

@app.get("/", response_class=HTMLResponse)
async def ui():
    html_path = Path(__file__).parent / "ui" / "index.html"
    if html_path.exists():
        return html_path.read_text(encoding='utf-8')
    return """
    <html><body style="font-family: monospace; padding: 20px;">
    <h1>🧠 Second Brain v4 API</h1>
    <p>API running. Create ui/index.html for web UI.</p>
    <ul>
      <li>POST /search - search brain</li>
      <li>POST /chat - chat with context</li>
      <li>POST /agent - multi-agent task</li>
      <li>GET /status</li>
    </ul>
    <script>
      async function search() {
        const q = document.getElementById('q').value;
        const res = await fetch('/search', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({query:q})});
        const data = await res.json();
        document.getElementById('results').textContent = JSON.stringify(data, null, 2);
      }
    </script>
    <input id="q" placeholder="search brain..." style="width:400px"><button onclick="search()">Search</button>
    <pre id="results"></pre>
    </body></html>
    """

@app.get("/status")
async def status():
    try:
        conn = await asyncpg.connect(NEON_DSN)
        cnt = await conn.fetchval("SELECT COUNT(*) FROM chunks")
        try:
            cnt_v4 = await conn.fetchval("SELECT COUNT(*) FROM chunks_v4")
        except:
            cnt_v4 = 0
        projs = await conn.fetch("SELECT project_id, COUNT(*) as c FROM chunks GROUP BY project_id")
        await conn.close()
        return {"status": "ok", "chunks": cnt, "chunks_v4": cnt_v4, "projects": {r["project_id"]: r["c"] for r in projs}}
    except Exception as e:
        return {"status": "error", "error": str(e)}

@app.post("/search")
async def api_search(req: SearchRequest):
    if not search_brain:
        return {"error": "search not available"}
    results = await search_brain(req.query, top_k=req.top_k)
    return {"query": req.query, "results": [{"project": r["project_id"], "file": r["file_path"], "content": r["content"][:1000], "score": float(r.get("similarity", 0))} for r in results]}

@app.post("/chat")
async def api_chat(req: ChatRequest):
    # Search + chat with Ollama
    results = await search_brain(req.query, top_k=req.top_k) if search_brain else []
    context = "\n\n".join(f"[{r['project_id']}/{r['file_path']}] {r['content'][:1000]}" for r in results)
    
    system = "You are Second Brain - senior engineer with perfect repo memory. Use context to answer."
    user_prompt = f"Context:\n{context}\n\nQuestion: {req.query}"
    
    async with aiohttp.ClientSession() as s:
        async with s.post(OLLAMA_CHAT_URL, json={
            "model": CHAT_MODEL,
            "messages": [{"role": "system", "content": system}, {"role": "user", "content": user_prompt}],
            "stream": False
        }) as r:
            data = await r.json()
            answer = data["message"]["content"]
    
    return {"query": req.query, "answer": answer, "context_used": len(results)}

@app.post("/agent")
async def api_agent(req: AgentRequest):
    # Run multi-agent task
    from brain_agent_v4 import run_multi_agent
    # Run in background? For now sync
    await run_multi_agent(req.task)
    return {"status": "completed", "task": req.task}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
