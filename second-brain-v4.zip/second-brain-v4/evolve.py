"""
Evolve - Self-evolution engine
Agent analyzes its own failures and improves its tools/code
"""
import asyncio
import os
from pathlib import Path
from datetime import datetime
import asyncpg
from dotenv import load_dotenv

load_dotenv()

NEON_DSN = os.getenv("NEON_DSN")

class Evolver:
    def __init__(self):
        self.root = Path(__file__).parent
        self.memory_dir = self.root / "memory"
        self.memory_dir.mkdir(exist_ok=True)
    
    async def analyze_failures(self):
        """Analyze recent conversations for failures"""
        conn = await asyncpg.connect(NEON_DSN)
        try:
            # Get recent tool failures
            rows = await conn.fetch("""
                SELECT content FROM conversations 
                WHERE content LIKE '%❌%' OR content LIKE '%Error%'
                ORDER BY created_at DESC LIMIT 20
            """)
            return [r["content"] for r in rows]
        except:
            return []
        finally:
            await conn.close()
    
    async def evolve_chunker(self):
        """Improve chunker based on search quality"""
        # Check if searches return low scores
        conn = await asyncpg.connect(NEON_DSN)
        try:
            # If many searches have <0.3 similarity, chunker may be bad
            low_score = await conn.fetchval("""
                SELECT COUNT(*) FROM conversations 
                WHERE content LIKE '%score=0.2%' OR content LIKE '%No results%'
            """)
            if low_score and low_score > 5:
                print(f"⚠️  Detected {low_score} low-score searches - chunker may need improvement")
                # Suggest: reduce chunk_size, improve AST parsing
                return "Consider reducing chunk_size to 800, improving AST chunker for better boundaries"
        except:
            pass
        finally:
            await conn.close()
        return None
    
    async def evolve_tools(self):
        """Check which tools fail most and improve them"""
        failures = await self.analyze_failures()
        if not failures:
            print("✅ No failures detected - system healthy")
            return
        
        print(f"🔍 Found {len(failures)} failures to analyze")
        
        # Common failure patterns and fixes
        fixes = []
        for f in failures:
            if "File not found" in f:
                fixes.append("Improve path resolution - add more fallback paths")
            if "embedding" in f.lower() and "vector" in f.lower():
                fixes.append("Vector dimension mismatch - check EMBED_DIM")
            if "timeout" in f.lower():
                fixes.append("Increase shell timeout, add retry")
        
        if fixes:
            lessons_path = self.memory_dir / "LESSONS.md"
            with open(lessons_path, 'a', encoding='utf-8') as fh:
                fh.write(f"\n## {datetime.now()} - Auto-evolution\n")
                for fix in set(fixes):
                    fh.write(f"- {fix}\n")
            print(f"📝 Added {len(set(fixes))} lessons to {lessons_path}")
    
    async def generate_improvements(self):
        """Use LLM to suggest code improvements"""
        # This would call Ollama to analyze own code and suggest improvements
        # For now, placeholder that creates TODOs
        improvements = [
            "Add AST chunking for TypeScript/JavaScript (currently only Python)",
            "Implement hybrid search (BM25 + vector) for better keyword matching",
            "Add code graph: track imports/calls between files",
            "Add conversation memory: store all agent interactions in Neon",
            "Add auto-commit: after successful task, commit with conventional message",
            "Add file watcher for MEMORY.md auto-reload",
            "Add streaming for agent tool calls",
        ]
        
        todo_path = self.root / "EVOLVE_TODO.md"
        with open(todo_path, 'w', encoding='utf-8') as f:
            f.write(f"# Evolution TODO - {datetime.now()}\n\n")
            for imp in improvements:
                f.write(f"- [ ] {imp}\n")
        
        print(f"📋 Generated evolution TODOs: {todo_path}")
        return improvements

async def evolve():
    print("🧬 Starting self-evolution...\n")
    ev = Evolver()
    
    print("1. Analyzing failures...")
    await ev.evolve_tools()
    
    print("\n2. Checking chunker quality...")
    suggestion = await ev.evolve_chunker()
    if suggestion:
        print(f"   Suggestion: {suggestion}")
    
    print("\n3. Generating improvements...")
    imps = await ev.generate_improvements()
    for imp in imps:
        print(f"   - {imp}")
    
    print("\n✅ Evolution complete. Check memory/LESSONS.md and EVOLVE_TODO.md")
    print("   Next: Implement TODOs, then run sb evolve again")

if __name__ == "__main__":
    asyncio.run(evolve())
