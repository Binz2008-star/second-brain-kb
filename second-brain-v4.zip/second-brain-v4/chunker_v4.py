import re
import ast
from pathlib import Path
from typing import List, Tuple, Optional
from dataclasses import dataclass

@dataclass
class CodeChunk:
    content: str
    type: str  # 'function', 'class', 'import', 'doc', 'generic'
    name: Optional[str]
    start_line: int
    end_line: int
    language: str

class ASTChunker:
    """
    SOTA chunker - understands code structure, not just char count
    Splits by functions, classes, with overlap and context
    """
    
    def __init__(self, max_chars=1500, overlap=200):
        self.max_chars = max_chars
        self.overlap = overlap
    
    def chunk_python(self, text: str) -> List[CodeChunk]:
        """AST-aware Python chunking"""
        try:
            tree = ast.parse(text)
        except:
            # Fallback to generic chunker
            return self.chunk_generic(text, "python")
        
        chunks = []
        lines = text.splitlines()
        
        # Extract imports as one chunk
        imports = []
        for node in tree.body:
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                imports.append(node)
        
        if imports:
            start = imports[0].lineno
            end = imports[-1].end_lineno if hasattr(imports[-1], 'end_lineno') else imports[-1].lineno
            content = "\n".join(lines[start-1:end])
            chunks.append(CodeChunk(content, "import", None, start, end, "python"))
        
        # Extract classes and functions with full bodies
        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                start = node.lineno
                end = getattr(node, 'end_lineno', start + 20)
                content = "\n".join(lines[start-1:end])
                # If class too big, split methods
                if len(content) > self.max_chars * 1.5:
                    # Keep class header + each method as separate chunk with class context
                    header = f"class {node.name}:\n"
                    for item in node.body:
                        if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            m_start = item.lineno
                            m_end = getattr(item, 'end_lineno', m_start + 10)
                            m_content = header + "\n".join(lines[m_start-1:m_end])
                            chunks.append(CodeChunk(m_content, "function", f"{node.name}.{item.name}", m_start, m_end, "python"))
                else:
                    chunks.append(CodeChunk(content, "class", node.name, start, end, "python"))
            
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start = node.lineno
                end = getattr(node, 'end_lineno', start + 20)
                content = "\n".join(lines[start-1:end])
                if len(content) > self.max_chars:
                    # Split large function with overlap
                    for sub in self.split_large(content, start, "python"):
                        chunks.append(sub)
                else:
                    chunks.append(CodeChunk(content, "function", node.name, start, end, "python"))
        
        # If no structured chunks found, fallback
        if len(chunks) <= 1:
            return self.chunk_generic(text, "python")
        
        return chunks
    
    def chunk_generic(self, text: str, lang: str) -> List[CodeChunk]:
        """Smart generic chunker - respects boundaries"""
        lines = text.splitlines()
        chunks = []
        current = []
        current_len = 0
        start_line = 1
        
        for i, line in enumerate(lines, 1):
            current.append(line)
            current_len += len(line) + 1
            
            # Natural break points
            is_break = (
                current_len >= self.max_chars and
                (line.strip() == "" or 
                 line.strip().startswith(("}", ")", "]", "```", "---")) or
                 i == len(lines))
            )
            
            if is_break:
                content = "\n".join(current)
                chunks.append(CodeChunk(content, "generic", None, start_line, i, lang))
                # Overlap
                overlap_lines = current[-3:] if len(current) > 3 else []
                current = overlap_lines
                current_len = sum(len(l) for l in current)
                start_line = i - len(overlap_lines) + 1
        
        if current:
            content = "\n".join(current)
            chunks.append(CodeChunk(content, "generic", None, start_line, len(lines), lang))
        
        return chunks
    
    def split_large(self, content: str, start_line: int, lang: str) -> List[CodeChunk]:
        """Split large function/class into overlapping pieces"""
        chunks = []
        lines = content.splitlines()
        for i in range(0, len(lines), self.max_chars - self.overlap):
            piece = "\n".join(lines[i:i+self.max_chars])
            chunks.append(CodeChunk(piece, "function", None, start_line + i, start_line + i + self.max_chars, lang))
        return chunks
    
    def chunk(self, text: str, file_path: str) -> List[CodeChunk]:
        ext = Path(file_path).suffix.lower()
        if ext == ".py":
            return self.chunk_python(text)
        else:
            lang = "javascript" if ext in (".js", ".ts", ".tsx") else "text"
            return self.chunk_generic(text, lang)

# Enhanced schema for v4 - hybrid search
V4_SCHEMA_SQL = """
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Projects table
CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    path TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enhanced chunks with hybrid search + code graph
CREATE TABLE IF NOT EXISTS chunks_v4 (
    id SERIAL PRIMARY KEY,
    project_id TEXT REFERENCES projects(id),
    file_path TEXT NOT NULL,
    chunk_index INT NOT NULL,
    chunk_type TEXT NOT NULL DEFAULT 'generic', -- function, class, import, generic
    chunk_name TEXT, -- function/class name
    content TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    language TEXT,
    start_line INT,
    end_line INT,
    -- Vectors
    embedding vector(768) NOT NULL,
    -- Hybrid search: tsvector for keyword
    content_tsv tsvector GENERATED ALWAYS AS (to_tsvector('english', content)) STORED,
    -- Code graph
    imports TEXT[], -- extracted imports
    calls TEXT[], -- function calls
    -- Metadata
    indexed_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(project_id, file_path, chunk_index)
);

-- Code graph edges (file -> file dependencies)
CREATE TABLE IF NOT EXISTS code_graph (
    id SERIAL PRIMARY KEY,
    project_id TEXT REFERENCES projects(id),
    source_file TEXT NOT NULL,
    target_file TEXT NOT NULL,
    relation TEXT NOT NULL, -- imports, calls, extends
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Conversations memory (agent learns)
CREATE TABLE IF NOT EXISTS conversations (
    id SERIAL PRIMARY KEY,
    session_id TEXT NOT NULL,
    role TEXT NOT NULL, -- user, assistant, tool
    content TEXT NOT NULL,
    tool_calls JSONB,
    project_id TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Long-term memory / lessons
CREATE TABLE IF NOT EXISTS memory (
    id SERIAL PRIMARY KEY,
    type TEXT NOT NULL, -- pattern, lesson, preference, fact
    content TEXT NOT NULL,
    project_id TEXT,
    embedding vector(768),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for hybrid search
CREATE INDEX IF NOT EXISTS idx_chunks_v4_embedding ON chunks_v4 USING ivfflat (embedding vector_cosine_ops) WITH (lists = 100);
CREATE INDEX IF NOT EXISTS idx_chunks_v4_tsv ON chunks_v4 USING GIN (content_tsv);
CREATE INDEX IF NOT EXISTS idx_chunks_v4_trgm ON chunks_v4 USING GIN (content gin_trgm_ops);
CREATE INDEX IF NOT EXISTS idx_chunks_v4_project ON chunks_v4 (project_id, file_path);
CREATE INDEX IF NOT EXISTS idx_memory_embedding ON memory USING ivfflat (embedding vector_cosine_ops);
CREATE INDEX IF NOT EXISTS idx_conversations_session ON conversations (session_id, created_at);

-- Hybrid search function (vector + keyword)
CREATE OR REPLACE FUNCTION hybrid_search(
    query_text TEXT,
    query_embedding vector(768),
    match_count INT DEFAULT 10,
    vector_weight FLOAT DEFAULT 0.7
) RETURNS TABLE (
    id INT,
    project_id TEXT,
    file_path TEXT,
    chunk_name TEXT,
    content TEXT,
    similarity FLOAT,
    rank FLOAT
) LANGUAGE plpgsql AS $$
BEGIN
    RETURN QUERY
    SELECT 
        c.id,
        c.project_id,
        c.file_path,
        c.chunk_name,
        c.content,
        (1 - (c.embedding <=> query_embedding))::FLOAT as similarity,
        (
            vector_weight * (1 - (c.embedding <=> query_embedding)) +
            (1 - vector_weight) * ts_rank(c.content_tsv, plainto_tsquery('english', query_text))
        )::FLOAT as rank
    FROM chunks_v4 c
    WHERE c.content_tsv @@ plainto_tsquery('english', query_text)
       OR (1 - (c.embedding <=> query_embedding)) > 0.2
    ORDER BY rank DESC
    LIMIT match_count;
END;
$$;
"""
