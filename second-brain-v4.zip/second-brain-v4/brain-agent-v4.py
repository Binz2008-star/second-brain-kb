#!/usr/bin/env python3
"""
🧠 SECOND BRAIN v4 - Multi-Agent System with Memory & Self-Evolution

Agents:
- Researcher: Searches brain, finds relevant code
- Architect: Plans solution, designs
- Editor: Writes code (Qwen Coder)
- Tester: Runs tests, fixes failures
- Memory: Learns and evolves

One terminal does all, but with specialized agents collaborating.
"""
import asyncio
import os
import sys
import json
import subprocess
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from dotenv import load_dotenv
import asyncpg
import aiohttp

load_dotenv()

NEON_DSN = os.getenv("NEON_DSN")
OLLAMA_EMBED_URL = os.getenv("OLLAMA_EMBED_URL", "http://127.0.0.1:11434/api/embed")
OLLAMA_CHAT_URL = os.getenv("OLLAMA_CHAT_URL", "http://127.0.0.1:11434/api/chat")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
# Use 16k models
ARCHITECT_MODEL = os.getenv("ARCHITECT_MODEL", "deepseek-r1:14b-16k")
EDITOR_MODEL = os.getenv("EDITOR_MODEL", "qwen2.5-coder:14b-16k")

# Projects
def resolve_proj(env_key, fallbacks):
    v = os.getenv(env_key)
    if v and Path(v).exists():
        return v
    for p in fallbacks:
        if Path(p).exists():
            return p
    return fallbacks[0] if fallbacks else None

PROJECTS = {
    "content-engine": resolve_proj("PROJECT_CONTENT_ENGINE", [r"X:\content engine\Robin-Content-Engine-v2", "/app/projects/content-engine"]),
    "lvyy": resolve_proj("PROJECT_LVYY", [r"C:\Users\loyal\lvyy-ai-sales-agent", "/app/projects/lvyy"]),
    "rico": resolve_proj("PROJECT_RICO", [r"X:\rico", "/app/projects/rico"]),
    "second-brain": str(Path(__file__).parent.parent / "second-brain-kb") if (Path(__file__).parent.parent / "second-brain-kb").exists() else str(Path(__file__).parent)
}
PROJECTS = {k: v for k, v in PROJECTS.items() if v and Path(v).exists()}
CURRENT_PROJECT = os.getenv("CURRENT_PROJECT", "lvyy" if "lvyy" in PROJECTS else list(PROJECTS.keys())[0] if PROJECTS else None)

# Memory
sys.path.insert(0, str(Path(__file__).parent))
try:
    from memory import MemoryManager
    memory_mgr = MemoryManager(NEON_DSN, memory_dir=str(Path(__file__).parent / "memory"))
except:
    memory_mgr = None

async def embed(text: str):
    async with aiohttp.ClientSession() as s:
        async with s.post(OLLAMA_EMBED_URL, json={"model": EMBED_MODEL, "input": text}) as r:
            j = await r.json()
            return j["embeddings"][0]

async def search_brain(query: str, top_k=8):
    q_emb = await embed(query)
    q_str = "[" + ",".join(f"{x:.6f}" for x in q_emb) + "]"
    conn = await asyncpg.connect(NEON_DSN)
    try:
        # Try v4 hybrid search, fallback to v3
        try:
            rows = await conn.fetch("SELECT * FROM hybrid_search($1, $2::vector, $3)", query, q_str, top_k*2)
        except:
            rows = await conn.fetch("""
                SELECT project_id, file_path, content, chunk_name, 1 - (embedding <=> $1::vector) as similarity
                FROM chunks_v4 ORDER BY embedding <=> $1::vector LIMIT $2
            """, q_str, top_k*3)
            if not rows:
                rows = await conn.fetch("""
                    SELECT project_id, file_path, content, NULL as chunk_name, 1 - (embedding <=> $1::vector) as similarity
                    FROM chunks ORDER BY embedding <=> $1::vector LIMIT $2
                """, q_str, top_k*3)
    finally:
        await conn.close()
    return rows[:top_k]

class Agent:
    def __init__(self, name: str, model: str, system_prompt: str):
        self.name = name
        self.model = model
        self.system = system_prompt
        self.history = []
    
    async def chat(self, user_msg: str, tools=None, tool_map=None):
        self.history.append({"role": "user", "content": user_msg})
        messages = [{"role": "system", "content": self.system}] + self.history
        
        async with aiohttp.ClientSession() as session:
            for _ in range(10):
                payload = {"model": self.model, "messages": messages, "stream": False}
                if tools:
                    payload["tools"] = tools
                
                async with session.post(OLLAMA_CHAT_URL, json=payload) as resp:
                    data = await resp.json()
                    msg = data["message"]
                
                if not msg.get("tool_calls"):
                    self.history.append(msg)
                    return msg.get("content", "")
                
                # Execute tools
                messages.append(msg)
                self.history.append(msg)
                for tc in msg["tool_calls"]:
                    fname = tc["function"]["name"]
                    args = tc["function"].get("arguments", {})
                    func = tool_map.get(fname) if tool_map else None
                    result = "Tool not found"
                    if func:
                        try:
                            result = await func(**args) if asyncio.iscoroutinefunction(func) else func(**args)
                        except Exception as e:
                            result = f"Error: {e}"
                    # Add tool result
                    tool_msg = {"role": "tool", "content": str(result)[:8000]}
                    messages.append(tool_msg)
                    self.history.append(tool_msg)
        
        return "Max tool loops reached"

# Tools for all agents
def tool_list_projects():
    return json.dumps(PROJECTS, indent=2)

def tool_switch_project(project_id: str):
    global CURRENT_PROJECT
    if project_id not in PROJECTS:
        return f"Not found. Available: {list(PROJECTS.keys())}"
    CURRENT_PROJECT = project_id
    os.chdir(PROJECTS[project_id])
    return f"Switched to {project_id}"

def tool_read(file_path: str):
    p = Path(PROJECTS[CURRENT_PROJECT]) / file_path
    if not p.exists():
        return f"Not found: {p}"
    return p.read_text(encoding='utf-8', errors='ignore')[:8000]

def tool_write(file_path: str, content: str):
    p = Path(PROJECTS[CURRENT_PROJECT]) / file_path
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding='utf-8')
    return f"Wrote {len(content)} chars to {p}"

def tool_shell(command: str):
    try:
        r = subprocess.run(command, shell=True, cwd=PROJECTS[CURRENT_PROJECT], capture_output=True, text=True, timeout=30)
        return f"Exit {r.returncode}:\n{r.stdout[-3000:]}\n{r.stderr[-1000:]}"
    except Exception as e:
        return f"Error: {e}"

TOOLS = [
    {"type": "function", "function": {"name": "search_brain", "description": "Search all repos", "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}}},
    {"type": "function", "function": {"name": "read_file", "description": "Read file", "parameters": {"type": "object", "properties": {"file_path": {"type": "string"}}, "required": ["file_path"]}}},
    {"type": "function", "function": {"name": "write_file", "description": "Write file", "parameters": {"type": "object", "properties": {"file_path": {"type": "string"}, "content": {"type": "string"}}, "required": ["file_path", "content"]}}},
    {"type": "function", "function": {"name": "run_shell", "description": "Run shell command", "parameters": {"type": "object", "properties": {"command": {"type": "string"}}, "required": ["command"]}}},
    {"type": "function", "function": {"name": "list_projects", "description": "List projects", "parameters": {"type": "object", "properties": {}}}},
    {"type": "function", "function": {"name": "switch_project", "description": "Switch project", "parameters": {"type": "object", "properties": {"project_id": {"type": "string"}}, "required": ["project_id"]}}},
]

TOOL_MAP = {
    "search_brain": lambda query: search_brain(query),
    "read_file": tool_read,
    "write_file": tool_write,
    "run_shell": tool_shell,
    "list_projects": tool_list_projects,
    "switch_project": tool_switch_project,
}

# Define specialized agents
ARCHITECT_SYSTEM = f"""You are Architect Agent - senior system designer.
Projects: {list(PROJECTS.keys())}, Current: {CURRENT_PROJECT}
You plan solutions, search brain for patterns, break tasks into steps.
ALWAYS search_brain first. Output a clear plan with files to create/edit.
"""

EDITOR_SYSTEM = f"""You are Editor Agent - expert coder (Qwen Coder).
You implement plans from Architect. You write clean, tested code.
Current project: {CURRENT_PROJECT} at {PROJECTS.get(CURRENT_PROJECT)}
Use tools to read/write files, run shell.
Small diffs, conventional commits.
"""

TESTER_SYSTEM = """You are Tester Agent - QA engineer.
You run tests, check lint, verify changes work.
Use run_shell to run pytest, npm test, etc. Fix failures.
"""

async def run_multi_agent(task: str):
    print(f"\n🚀 Multi-Agent Task: {task}\n")
    
    # 1. Researcher phase - search brain
    print("🔍 [Researcher] Searching brain...")
    brain_results = await search_brain(task, top_k=8)
    brain_context = "\n".join(f"[{r['project_id']}/{r['file_path']}] {r['content'][:800]}" for r in brain_results)
    print(f"  Found {len(brain_results)} relevant chunks")
    
    # 2. Architect phase
    architect = Agent("Architect", ARCHITECT_MODEL, ARCHITECT_SYSTEM)
    plan = await architect.chat(
        f"Task: {task}\n\nRelevant code from brain:\n{brain_context}\n\nCreate a plan: which project, which files, what changes, in what order. Be specific.",
        tools=TOOLS, tool_map=TOOL_MAP
    )
    print(f"\n📐 [Architect] Plan:\n{plan}\n")
    
    # 3. Editor phase
    editor = Agent("Editor", EDITOR_MODEL, EDITOR_SYSTEM)
    implementation = await editor.chat(
        f"Task: {task}\n\nArchitect plan:\n{plan}\n\nRelevant code:\n{brain_context}\n\nImplement it. Use tools to create/edit files.",
        tools=TOOLS, tool_map=TOOL_MAP
    )
    print(f"\n✏️ [Editor] Implementation:\n{implementation}\n")
    
    # 4. Tester phase
    tester = Agent("Tester", EDITOR_MODEL, TESTER_SYSTEM)
    test_result = await tester.chat(
        f"Task was: {task}\nPlan: {plan}\nImplementation done. Now test it - run relevant tests, lint, check if it works. Fix if needed.",
        tools=TOOLS, tool_map=TOOL_MAP
    )
    print(f"\n🧪 [Tester] Results:\n{test_result}\n")
    
    # 5. Memory - learn
    if memory_mgr:
        await memory_mgr.add_memory("lesson", f"Task: {task}\nPlan: {plan[:500]}\nResult: {test_result[:500]}", CURRENT_PROJECT)
    
    print(f"\n✅ Multi-agent task complete: {task}")

async def interactive_v4():
    print(f"""
╔══════════════════════════════════════════════════════╗
║  🧠 SECOND BRAIN v4 - Multi-Agent Self-Evolving      ║
║  Architect ({ARCHITECT_MODEL})                        ║
║  Editor ({EDITOR_MODEL})                              ║
║  Projects: {', '.join(PROJECTS.keys())}
║  Memory: {memory_mgr.memory_dir if memory_mgr else 'disabled'}
╚══════════════════════════════════════════════════════╝

Commands:
  /status, /projects, /switch <id>, /memory, /exit
  Or just describe task: "add auth from content-engine to lvyy"
""")
    
    while True:
        try:
            user_in = input(f"\n[{CURRENT_PROJECT}] You: ").strip()
            if not user_in:
                continue
            if user_in in ("/exit", "/quit"):
                break
            if user_in == "/projects":
                print(tool_list_projects())
                continue
            if user_in.startswith("/switch "):
                print(tool_switch_project(user_in.split()[1]))
                continue
            if user_in == "/memory" and memory_mgr:
                print(memory_mgr.get_context()[:4000])
                continue
            
            await run_multi_agent(user_in)
            
        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"❌ {e}")
            import traceback; traceback.print_exc()

if __name__ == "__main__":
    if len(sys.argv) > 1:
        asyncio.run(run_multi_agent(" ".join(sys.argv[1:])))
    else:
        asyncio.run(interactive_v4())
